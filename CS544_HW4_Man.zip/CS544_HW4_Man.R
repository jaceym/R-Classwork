###cs 544 hw 4 jacey jixing man
## part 1
#a
n <- 6; p <- 1/2;
dbinom(6,size = n,prob = p)

pmf = dbinom(0:n, size = n, prob = p)
pmf

# b

cdf <- c(0,cumsum(pmf))
cdfplot <- stepfun(0:n,cdf)
plot(cdfplot,verticals = FALSE,pch = 16, main = "Strick Out", xlab = "x",ylab = "CDF")

# c
n <- 6; p <- 3/4;
dbinom(6,size = n,prob = p)

pmf <- dbinom(0:n,size = n,prob = p)
heights <- dbinom(0:n, size = n, prob = p)
plot(0:n, heights, type = "h",
     main = "Strick Out of X", xlab = "x", ylab = "PMF")
points(0:n, heights, pch = 16)   

cdf <- c(0,cumsum(pmf))
cdfplot <- stepfun(0:n,cdf)
plot(cdfplot,verticals = FALSE,pch = 16, main = "Strick Out", xlab = "x",ylab = "CDF")

# d
n <- 6; p <- 1/3;
dbinom(6,size = n,prob = p)

pmf <- dbinom(0:n,size = n,prob = p)
heights <- dbinom(0:n, size = n, prob = p)
plot(0:n, heights, type = "h",
     main = "Strick Out of X", xlab = "x", ylab = "PMF")
points(0:n, heights, pch = 16) 

cdf <- c(0,cumsum(pmf))
cdfplot <- stepfun(0:n,cdf)
plot(cdfplot,verticals = FALSE,pch = 16, main = "Strick Out", xlab = "x",ylab = "CDF")

# e
## the graph is less steep for 30% compare to 70% for the cdf plot, and for the pmf plot, the graph shows 
## upside "U" curve in almost mirrior image, which matches the probablilty, one is in the smaller percentale 1/3,
## and the other is in the larger percentale 3/4

## part 2
#a 
n1 <- 10; p1 <- 0.8;
dbinom(4,size = n1,prob = p1)
# b
n1 <- 10; p1 <- 0.8;
pbinom(4,size = n1,prob= p1)
# c
n1 <- 10; p1 <- 0.8;
dbinom(10,size = n1,prob = p1)
dbinom(0:n1, size = n1, prob = p1)
# d
pmf = dbinom(0:n1, size = n1, prob = p1)
pmf
cdf <- c(0,cumsum(pmf))
cdf

## part 3
#a
dpois(3,lambda = 10)
#b
ppois(3,lambda=10,lower=FALSE)
#c
ppois(5,lambda=10) - ppois(1,lambda=10)
#d
pmf <- dpois(0:20,lambda=10)
pmf
plot(0:20,pmf,type="h", xlab = "x",ylab="PMF",ylim = c(0,0.15))

## part 4
#a
# 60 
dunif(60,min = 60,max = 100)
# 80
dunif(80,min= 60,max=100)
# 100
dunif(100,min=60,max=100)
### explaination, as uniform distribution, the porbability of
### scroing 60, 80, and 100 should all be the same. which is 0.025

#b
x <- 60:100
f <- rep (rep(1/41,41)) ## since this is inclusive of 60 and 100
## the number of number between 60 and 100 should be (100-60+1)
## therefore 41.
mu <- sum(x*f) ## the mean
mu

sigmaSquare <- sum((x-mu)^2 *f)
sigma <- sqrt(sigmaSquare)
sigma  ## standard deviation

#c
punif(70,min=60,max=100)

#d
punif(80,min=60,max=100,lower.tail=FALSE) ## greater than 80

#e
punif(100,min=60,max=100) - punif(90, min=60, max=100)

## part 5
#a
x <- seq(10,200)
pdf <- dnorm(x,mean = 100,sd = 10)
plot(x, pdf, type="l", col="red", xlim=c(0,200))
## the normal pdf plot 

#b
mu = 100
sigma = 10
pnorm(q = 90, mean = mu, sd = sigma, lower.tail = FALSE) 

#c
pnorm(q = 90, mean = mu, sd = sigma) - pnorm(80, mean = mu, sd = sigma)
#d
pnorm(mu+sigma,mean = mu, sd = sigma) - pnorm(mu - sigma,mean = mu,sd=sigma)
# with 1 stdev
pnorm(mu+2*sigma,mean = mu, sd = sigma) - pnorm(mu - 2*sigma,mean = mu,sd=sigma)
# with 2 stdev
pnorm(mu+3*sigma,mean = mu, sd = sigma) - pnorm(mu - 3*sigma,mean = mu,sd=sigma)
# with 3 stdev

#e
qnorm(p = 0.90, mean = mu, sd = sigma)  # what number will the 90% fall
qnorm(p = 0.50, mean = mu, sd = sigma)  # what number will the middle (50) percent fall
## anwser, between 100 and 112.8155

#f
y <- rnorm(n = 10000, mean = mu, sd = sigma)

hist(y, breaks = 25, xaxt = "n")
axis(side = 1, at = seq(from = 40, to = 180, by = 10), labels = TRUE)
## the above plot shows the money spent with normal distrubution with 10000 visitor

## part 6
#a
pexp(2/60, rate=18)
#b
pexp(5/60, rate = 18)
# c 
pexp(5/60, rate = 18) - pexp(2/60, rate=18)
# d
x <- seq(from = 0, to =1 , by = 1/60)
cdf <- pexp(x,rate = 18)
plot(x,cdf,type="l",col="red")
# cdf as customer support support recieves 18 call per hour
































